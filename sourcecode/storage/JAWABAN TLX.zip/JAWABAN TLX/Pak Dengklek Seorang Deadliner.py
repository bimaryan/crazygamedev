def hitung_sisa_waktu(N):
    jam = N // 3600
    N %= 3600
    menit = N // 60
    detik = N % 60
    return jam, menit, detik

N = int(input())

jam, menit, detik = hitung_sisa_waktu(N)

print(jam)
print(menit)
print(detik)