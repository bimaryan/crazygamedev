N = int(input())

gerbong = list(map(int, input().split()))

susunan_balik = gerbong[::-1]
output = ",".join(str(x) for x in susunan_balik)
print(output)