# Read the input
password = input()

# Check the password strength
if len(password) >= 8 and any(c.isupper() for c in password) and any(c.islower() for c in password) and any(c.isdigit() for c in password) and any(not c.isalnum() for c in password):
    print("Kuat")
elif len(password) > 12 and any(c.isalpha() for c in password):
    print("AgakKuat")
else:
    print("Lemah")