def calculate_time(A, X):
    N = X // A  # Jumlah maj
    M = X % A   # Sisa netim

    return N, M

# Membaca input A dan X
A, X = map(int, input().split())

# Menghitung format waktu di Oivworld setelah berlalu X netim
N, M = calculate_time(A, X)

# Menampilkan hasil
print(N, M)