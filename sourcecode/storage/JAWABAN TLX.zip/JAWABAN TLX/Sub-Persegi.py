def count_subquares(N):
    total = 0
    for i in range(1, N+1):
        total += i**2

    return total

# Membaca input N
N = int(input())

# Menghitung jumlah subpersegi
jumlah_subpersegi = count_subquares(N)

# Menampilkan hasil
print(jumlah_subpersegi)