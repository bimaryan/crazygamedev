# Membaca input N dan M
N, M = map(int, input().split())

# Membaca ukuran kaki bebek-bebek
bebek_sizes = []
for _ in range(N):
    bebek_sizes.append(int(input()))

# Membaca ukuran sepatu-sepatu
sepatu_sizes = []
for _ in range(M):
    sepatu_sizes.append(int(input()))

# Menghitung banyak bebek yang dapat menggunakan sepatu baru
count = 0
for bebek_size in bebek_sizes:
    for sepatu_size in sepatu_sizes:
        if bebek_size == sepatu_size or bebek_size == sepatu_size - 1:
            count += 1
            sepatu_sizes.remove(sepatu_size)
            break

# Menampilkan hasil
print(count)