def pilih_ukuran_baju(B, P, L):
    if B <= 10 and P <= 40 and L <= 90:
        return 'S'
    elif B <= 14 and P <= 60 and L <= 120:
        return 'M'
    elif B <= 18 and P <= 80 and L <= 180:
        return 'L'
    else:
        return 'X'

B, P, L = map(int, input().split())

ukuran_baju = pilih_ukuran_baju(B, P, L)

print(ukuran_baju)