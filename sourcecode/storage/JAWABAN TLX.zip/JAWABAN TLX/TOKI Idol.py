# Membaca input nilai dari 3 juri
nilai_juri_1 = int(input())
nilai_juri_2 = int(input())
nilai_juri_3 = int(input())

# Menghitung total nilai dan mengecek apakah peserta lolos atau tidak
total_nilai = nilai_juri_1 + nilai_juri_2 + nilai_juri_3

if total_nilai >= 200 and nilai_juri_1 >= 50 and nilai_juri_2 >= 50 and nilai_juri_3 >= 50:
    print("Lolos")
else:
    print("Tidak Lolos")