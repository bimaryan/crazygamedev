# Membaca input N dan D
N, D = map(int, input().split())

# Menghitung suhu maksimal yang dapat dihasilkan
suhu_maksimal = D ** (N // D)

# Menentukan apakah mungkin menghasilkan api
if suhu_maksimal > N:
    print("YES")
else:
    print("NO")