# Read the input
N = int(input())

# Count the number of trailing zeros
count = 0
while N >= 5:
    N //= 5
    count += N

# Print the result
print(count)