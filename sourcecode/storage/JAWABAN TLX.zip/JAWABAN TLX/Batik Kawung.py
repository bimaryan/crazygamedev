def print_batik_kawung(K, C, A):
    for i in range(K):
        for j in range(K):
            if i == j or i + j == K - 1:
                print(A, end='')
            else:
                print(C, end='')
        print()

# Membaca input ukuran motif (K), karakter (C), dan angka (A)
K, C, A = input().split()
K = int(K)

# Mencetak motif Batik Kawung
print_batik_kawung(K, C, A)