def hitung_operasi(X, Y):

    penjumlahan = X + Y

    pengurangan = X - Y

    perkalian = X * Y

    bagian_bulat = X // Y

    sisa_pembagian = X % Y

    return penjumlahan, pengurangan, perkalian, bagian_bulat, sisa_pembagian

X, Y = map(int, input().split())

hasil_operasi = hitung_operasi(X, Y)

for hasil in hasil_operasi:
    print(hasil)