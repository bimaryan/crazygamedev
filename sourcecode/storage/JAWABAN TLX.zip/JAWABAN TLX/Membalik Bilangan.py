def balik_bilangan(bilangan):
    return int(str(bilangan)[::-1])

N = int(input())

for _ in range(N):
    bilangan = int(input())
    hasil_balik = balik_bilangan(bilangan)
    print(hasil_balik)