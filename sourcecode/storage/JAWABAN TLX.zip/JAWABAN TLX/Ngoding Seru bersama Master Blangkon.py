# Membaca input A, B, C, dan K
A, B, C, K = map(int, input().split())

# Menyusun angka-angka sesuai dengan nilai K
if K == 0:
    sorted_numbers = sorted([A, B, C], reverse=True)
else:
    sorted_numbers = sorted([A, B, C])

# Menampilkan hasil
print(*sorted_numbers)