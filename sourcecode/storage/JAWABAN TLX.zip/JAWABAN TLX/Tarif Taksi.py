# Read the number of test cases
T = int(input())

# Iterate over each test case
for _ in range(T):
    # Read the values for A, B, and L
    A, B, L = map(int, input().split())

    # Calculate the total cost
    if L <= 2000:
        total_cost = A
    else:
        total_cost = A + ((L - 2000) // 100) * B
        if (L - 2000) % 100 != 0:
            total_cost += B

    # Print the total cost
    print(total_cost)