def cek_nilai_diperbolehkan(N):
    if N >= 0 and N <= 100:
        return "YA"
    else:
        return "TIDAK"

N = int(input())

hasil = cek_nilai_diperbolehkan(N)

print(hasil)