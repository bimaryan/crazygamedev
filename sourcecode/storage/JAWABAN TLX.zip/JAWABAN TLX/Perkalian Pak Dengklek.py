# Membaca input bilangan A dan B
A, B = map(int, input().split())

# Mengubah bilangan A dan B menjadi list digit
digit_A = [int(d) for d in str(A)]
digit_B = [int(d) for d in str(B)]

# Menghitung hasil perkalian menurut cara Pak Dengklek
hasil = sum(digit_A[i] * digit_B[j] for i in range(len(digit_A)) for j in range(len(digit_B)))

# Menampilkan hasil perkalian
print(hasil)