P, Q = map(int, input().split())

total_bunga = P * P + Q * Q + 1

if total_bunga % 4 == 0:
    bunga_per_teman = total_bunga // 4
    print(bunga_per_teman)
else:
    print(-1)