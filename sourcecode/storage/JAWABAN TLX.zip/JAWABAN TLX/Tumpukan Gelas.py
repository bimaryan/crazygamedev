# Read the input
N = int(input())

# Check if a glass needs to be taken or not
if N % 2 == 0:
    print("Tidak")
else:
    print("Perlu")