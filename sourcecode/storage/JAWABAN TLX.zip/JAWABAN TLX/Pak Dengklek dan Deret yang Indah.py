def cetak_deret_indah(S0, N, D):
    deret = [S0]
    for i in range(1, N):
        deret.append(deret[i-1] + D)
    return deret

S0, N, D = map(int, input().split())

deret_indah = cetak_deret_indah(S0, N, D)
for elemen in deret_indah:
    print(elemen)