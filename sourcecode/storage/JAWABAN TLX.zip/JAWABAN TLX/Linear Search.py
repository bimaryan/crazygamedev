N, D = map(int, input().split())

barisan = [int(input()) for _ in range(N)]

indeks = -1
for i in range(N):
    if barisan[i] == D:
        indeks = i
        break

print(indeks)