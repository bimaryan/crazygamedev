# Read the input
year = int(input())

# Generate the IdeaFuse website address
website = "http://ideafuse.mikroskil.ac.id/{}/".format(year)

# Print the website address
print(website)