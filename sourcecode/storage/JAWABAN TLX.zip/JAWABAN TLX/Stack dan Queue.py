class QueueStack:
    def __init__(self):
        self.queue = []
        self.stack = []

    def push_front(self, element):
        self.stack.append(element)

    def push_back(self, element):
        self.queue.append(element)

    def pop_front(self):
        if self.stack:
            return self.stack.pop()
        elif self.queue:
            return self.queue.pop(0)
        else:
            return None

    def pop_back(self):
        if self.queue:
            return self.queue.pop()
        elif self.stack:
            return self.stack.pop()
        else:
            return None

    def get_elements(self):
        return self.stack[::-1] + self.queue

# Membaca input jumlah operasi
N = int(input())

# Membuat objek QueueStack
queue_stack = QueueStack()

# Melakukan operasi memasukkan dan mengeluarkan elemen
for _ in range(N):
    command = input().split()
    if command[0] == 'push_front':
        queue_stack.push_front(int(command[1]))
    elif command[0] == 'push_back':
        queue_stack.push_back(int(command[1]))
    elif command[0] == 'pop_front':
        queue_stack.pop_front()
    elif command[0] == 'pop_back':
        queue_stack.pop_back()

# Mendapatkan elemen-elemen pada kondisi akhir struktur data
elements = queue_stack.get_elements()

# Mencetak elemen-elemen pada kondisi akhir struktur data
for element in elements:
    print(element)