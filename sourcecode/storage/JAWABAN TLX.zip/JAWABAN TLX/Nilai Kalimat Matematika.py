input_str = input()

A, op, B = input_str.split()

A = int(A)
B = int(B)

if op == '+':
    hasil = A + B
elif op == '-':
    hasil = A - B
elif op == '*':
    hasil = A * B
elif op == '<':
    hasil = A < B
elif op == '>':
    hasil = A > B
elif op == '=':
    hasil = A == B

if op in ['+', '-', '*']:
    print(hasil)
else:
    if hasil:
        print("benar")
    else:
        print("salah")