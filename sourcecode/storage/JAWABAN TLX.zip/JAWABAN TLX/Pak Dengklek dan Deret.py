# Read the input
N = int(input())

# Initialize the sum variable
sum = 0

# Generate the series of the sum from 1 to N
series = ""
for i in range(1, N+1):
    sum += i
    series += str(i)
    if i != N:
        series += "+"

# Print the series
print(series)