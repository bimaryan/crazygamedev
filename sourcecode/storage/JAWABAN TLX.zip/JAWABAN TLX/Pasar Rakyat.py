def hitung_jumlah_hari(N, D):
    gcd = D[0]

    for i in range(1, N):
        gcd = find_gcd(gcd, D[i])

    return lcm(D) // gcd

def find_gcd(a, b):
    while b:
        a, b = b, a % b
    return a

def lcm(numbers):
    lcm_value = numbers[0]
    for i in range(1, len(numbers)):
        lcm_value = lcm_of_two(lcm_value, numbers[i])
    return lcm_value

def lcm_of_two(a, b):
    return (a * b) // find_gcd(a, b)

N = int(input())
D = []
for _ in range(N):
    frekuensi = int(input())
    D.append(frekuensi)

jumlah_hari = hitung_jumlah_hari(N, D)

print(jumlah_hari)