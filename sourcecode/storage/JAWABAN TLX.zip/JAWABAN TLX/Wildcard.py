def cocokkan_pattern(pattern, words):
    hasil_cocok = []
    for word in words:
        if cocok(pattern, word):
            hasil_cocok.append(word)
    return hasil_cocok

def cocok(pattern, word):
    if len(pattern) == 1 and pattern == '*':
        return True

    if len(word) < len(pattern) - 1:
        return False

    if pattern[0] == '*':
        return cocok(pattern[1:], word) or (len(word) > 0 and cocok(pattern, word[1:]))
    elif len(word) > 0 and (pattern[0] == word[0] or pattern[0] == '?'):
        return cocok(pattern[1:], word[1:])
    else:
        return False

pattern = input().strip()

N = int(input())
words = []
for _ in range(N):
    word = input().strip()
    words.append(word)

hasil_cocok = cocokkan_pattern(pattern, words)

for kata in hasil_cocok:
    print(kata)