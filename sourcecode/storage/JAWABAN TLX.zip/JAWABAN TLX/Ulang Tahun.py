N, Q = map(int, input().split())

buku_kuning = {}
for _ in range(N):
    nama, nomor_telepon = input().split()
    buku_kuning[nama] = nomor_telepon

for _ in range(Q):
    nama_teman = input()
    nomor_telepon = buku_kuning[nama_teman]
    print(nomor_telepon)