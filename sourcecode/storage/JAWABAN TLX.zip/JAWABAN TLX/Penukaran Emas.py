def get_maximum_gold_weight(weight):
    # Basis: jika berat emas kurang dari atau sama dengan 1, maka tidak ada penukaran yang bisa dilakukan
    if weight <= 1:
        return weight

    # Menghitung berat maksimum yang dapat diperoleh dari masing-masing bagian dan menjumlahkannya
    maximum_weight = get_maximum_gold_weight(weight // 2) + get_maximum_gold_weight(weight // 3) + get_maximum_gold_weight(weight // 4)

    # Memilih berat maksimum antara berat semula dan berat maksimum dari penukaran
    return max(weight, maximum_weight)

# Membaca input berat emas
weight = int(input())

# Memanggil fungsi get_maximum_gold_weight dan mencetak hasil
print(get_maximum_gold_weight(weight))